const Booking = require('../models/Booking');
const Flight = require('../models/Flight');

// @desc    Get bookings (own bookings for users, all bookings for admin)
// @route   GET /api/bookings?status=&search=&page=&limit=
// @access  Private
const getBookings = async (req, res, next) => {
  try {
    const { status, search, page = 1, limit = 8 } = req.query;
    const filter = {};

    // Regular users only ever see their own bookings
    if (req.user.role !== 'admin') {
      filter.userId = req.user._id;
    }

    if (status) filter.bookingStatus = status;
    if (search) {
      filter.$or = [
        { passengerName: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }

    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.max(parseInt(limit, 10) || 8, 1);

    const total = await Booking.countDocuments(filter);
    const bookings = await Booking.find(filter)
      .populate('flightId')
      .populate('userId', 'name email')
      .sort('-createdAt')
      .skip((pageNum - 1) * limitNum)
      .limit(limitNum);

    res.json({ bookings, page: pageNum, pages: Math.ceil(total / limitNum), total });
  } catch (error) {
    next(error);
  }
};

// @desc    Get a single booking
// @route   GET /api/bookings/:id
// @access  Private
const getBookingById = async (req, res, next) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate('flightId')
      .populate('userId', 'name email');

    if (!booking) return res.status(404).json({ message: 'Booking not found' });

    // Users can only view their own bookings
    if (req.user.role !== 'admin' && booking.userId._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to view this booking' });
    }

    res.json(booking);
  } catch (error) {
    next(error);
  }
};

// @desc    Create a new booking (books seats on a flight)
// @route   POST /api/bookings
// @access  Private
const createBooking = async (req, res, next) => {
  try {
    const { flightId, passengerName, email, phone, seats } = req.body;

    if (!flightId || !passengerName || !email || !phone || !seats) {
      return res.status(400).json({ message: 'Please provide all required booking fields' });
    }

    const numSeats = parseInt(seats, 10);
    if (isNaN(numSeats) || numSeats < 1) {
      return res.status(400).json({ message: 'Number of seats must be at least 1' });
    }

    const flight = await Flight.findById(flightId);
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }

    // Seat availability validation - re-checked atomically below as well
    if (flight.availableSeats < numSeats) {
      return res.status(400).json({
        message: `Only ${flight.availableSeats} seat(s) available on this flight`,
      });
    }

    // Atomically decrement seats only if enough remain (guards against race conditions
    // between concurrent bookings without needing a replica-set transaction)
    const updatedFlight = await Flight.findOneAndUpdate(
      { _id: flightId, availableSeats: { $gte: numSeats } },
      { $inc: { availableSeats: -numSeats } },
      { new: true }
    );

    if (!updatedFlight) {
      return res.status(400).json({ message: 'Seats were just booked by someone else. Please try again.' });
    }

    const totalPrice = updatedFlight.price * numSeats;

    const booking = await Booking.create({
      userId: req.user._id,
      flightId,
      passengerName,
      email,
      phone,
      seats: numSeats,
      totalPrice,
      bookingStatus: 'confirmed',
    });

    const populated = await Booking.findById(booking._id).populate('flightId');
    res.status(201).json(populated);
  } catch (error) {
    next(error);
  }
};

// @desc    Update a booking (passenger details, or admin status change)
// @route   PUT /api/bookings/:id
// @access  Private
const updateBooking = async (req, res, next) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) return res.status(404).json({ message: 'Booking not found' });

    if (req.user.role !== 'admin' && booking.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to update this booking' });
    }

    const { passengerName, email, phone, bookingStatus } = req.body;
    if (passengerName) booking.passengerName = passengerName;
    if (email) booking.email = email;
    if (phone) booking.phone = phone;
    if (bookingStatus && req.user.role === 'admin') booking.bookingStatus = bookingStatus;

    const updated = await booking.save();
    res.json(updated);
  } catch (error) {
    next(error);
  }
};

// @desc    Cancel / delete a booking (restores seats to the flight)
// @route   DELETE /api/bookings/:id
// @access  Private
const cancelBooking = async (req, res, next) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) return res.status(404).json({ message: 'Booking not found' });

    if (req.user.role !== 'admin' && booking.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to cancel this booking' });
    }

    if (booking.bookingStatus !== 'cancelled') {
      // Restore seats back to the flight's available pool
      const flight = await Flight.findById(booking.flightId);
      if (flight) {
        flight.availableSeats += booking.seats;
        await flight.save();
      }
    }

    booking.bookingStatus = 'cancelled';
    await booking.save();

    res.json({ message: 'Booking cancelled successfully' });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getBookings,
  getBookingById,
  createBooking,
  updateBooking,
  cancelBooking,
};
