const Flight = require('../models/Flight');

// @desc    Get all flights (supports search/filter/pagination/sorting)
// @route   GET /api/flights?source=&destination=&date=&page=&limit=&sort=
// @access  Public
const getFlights = async (req, res, next) => {
  try {
    const { source, destination, date, page = 1, limit = 9, sort = 'date' } = req.query;

    const filter = {};
    if (source) filter.source = { $regex: source, $options: 'i' };
    if (destination) filter.destination = { $regex: destination, $options: 'i' };
    if (date) {
      // Match flights on the given calendar day
      const start = new Date(date);
      start.setHours(0, 0, 0, 0);
      const end = new Date(date);
      end.setHours(23, 59, 59, 999);
      filter.date = { $gte: start, $lte: end };
    }

    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.max(parseInt(limit, 10) || 9, 1);

    const sortOptions = {
      date: 'date',
      priceAsc: 'price',
      priceDesc: '-price',
      departure: 'departureTime',
    };
    const sortBy = sortOptions[sort] || 'date';

    const total = await Flight.countDocuments(filter);
    const flights = await Flight.find(filter)
      .sort(sortBy)
      .skip((pageNum - 1) * limitNum)
      .limit(limitNum);

    res.json({
      flights,
      page: pageNum,
      pages: Math.ceil(total / limitNum),
      total,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single flight by id
// @route   GET /api/flights/:id
// @access  Public
const getFlightById = async (req, res, next) => {
  try {
    const flight = await Flight.findById(req.params.id);
    if (!flight) return res.status(404).json({ message: 'Flight not found' });
    res.json(flight);
  } catch (error) {
    next(error);
  }
};

// @desc    Create a new flight
// @route   POST /api/flights
// @access  Private/Admin
const createFlight = async (req, res, next) => {
  try {
    const {
      flightNumber,
      airline,
      source,
      destination,
      departureTime,
      arrivalTime,
      date,
      price,
      availableSeats,
    } = req.body;

    if (
      !flightNumber || !airline || !source || !destination ||
      !departureTime || !arrivalTime || !date || price === undefined || availableSeats === undefined
    ) {
      return res.status(400).json({ message: 'Please provide all required flight fields' });
    }

    if (source.trim().toLowerCase() === destination.trim().toLowerCase()) {
      return res.status(400).json({ message: 'Source and destination cannot be the same' });
    }

    const flight = await Flight.create({
      flightNumber,
      airline,
      source,
      destination,
      departureTime,
      arrivalTime,
      date,
      price,
      availableSeats,
      totalSeats: availableSeats,
    });

    res.status(201).json(flight);
  } catch (error) {
    next(error);
  }
};

// @desc    Update a flight
// @route   PUT /api/flights/:id
// @access  Private/Admin
const updateFlight = async (req, res, next) => {
  try {
    const flight = await Flight.findById(req.params.id);
    if (!flight) return res.status(404).json({ message: 'Flight not found' });

    Object.assign(flight, req.body);
    const updated = await flight.save();
    res.json(updated);
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a flight
// @route   DELETE /api/flights/:id
// @access  Private/Admin
const deleteFlight = async (req, res, next) => {
  try {
    const flight = await Flight.findById(req.params.id);
    if (!flight) return res.status(404).json({ message: 'Flight not found' });

    await flight.deleteOne();
    res.json({ message: 'Flight removed successfully' });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getFlights,
  getFlightById,
  createFlight,
  updateFlight,
  deleteFlight,
};
