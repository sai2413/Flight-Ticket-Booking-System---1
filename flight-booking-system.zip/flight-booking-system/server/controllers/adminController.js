const User = require('../models/User');
const Flight = require('../models/Flight');
const Booking = require('../models/Booking');

// @desc    Get admin dashboard stats (total users, flights, revenue, bookings)
// @route   GET /api/admin/stats
// @access  Private/Admin
const getStats = async (req, res, next) => {
  try {
    const totalUsers = await User.countDocuments({ role: 'user' });
    const totalFlights = await Flight.countDocuments();
    const totalBookings = await Booking.countDocuments({ bookingStatus: 'confirmed' });

    const revenueAgg = await Booking.aggregate([
      { $match: { bookingStatus: 'confirmed' } },
      { $group: { _id: null, total: { $sum: '$totalPrice' } } },
    ]);
    const totalRevenue = revenueAgg.length > 0 ? revenueAgg[0].total : 0;

    res.json({ totalUsers, totalFlights, totalBookings, totalRevenue });
  } catch (error) {
    next(error);
  }
};

module.exports = { getStats };
