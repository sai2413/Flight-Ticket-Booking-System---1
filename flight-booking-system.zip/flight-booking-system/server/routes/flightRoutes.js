const express = require('express');
const router = express.Router();
const {
  getFlights,
  getFlightById,
  createFlight,
  updateFlight,
  deleteFlight,
} = require('../controllers/flightController');
const { protect, admin } = require('../middleware/auth');

router.route('/')
  .get(getFlights)          // Public - search & list flights
  .post(protect, admin, createFlight); // Admin only

router.route('/:id')
  .get(getFlightById)                  // Public - flight details
  .put(protect, admin, updateFlight)   // Admin only
  .delete(protect, admin, deleteFlight); // Admin only

module.exports = router;
