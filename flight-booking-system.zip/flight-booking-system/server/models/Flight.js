const mongoose = require('mongoose');

const flightSchema = new mongoose.Schema(
  {
    flightNumber: {
      type: String,
      required: [true, 'Flight number is required'],
      trim: true,
      uppercase: true,
    },
    airline: {
      type: String,
      required: [true, 'Airline name is required'],
      trim: true,
    },
    source: {
      type: String,
      required: [true, 'Source city is required'],
      trim: true,
    },
    destination: {
      type: String,
      required: [true, 'Destination city is required'],
      trim: true,
    },
    departureTime: {
      type: String, // e.g. "08:30"
      required: [true, 'Departure time is required'],
    },
    arrivalTime: {
      type: String, // e.g. "11:00"
      required: [true, 'Arrival time is required'],
    },
    date: {
      type: Date,
      required: [true, 'Flight date is required'],
    },
    price: {
      type: Number,
      required: [true, 'Ticket price is required'],
      min: [0, 'Price cannot be negative'],
    },
    totalSeats: {
      type: Number,
      required: true,
      default: function () {
        return this.availableSeats;
      },
    },
    availableSeats: {
      type: Number,
      required: [true, 'Available seats is required'],
      min: [0, 'Available seats cannot be negative'],
    },
  },
  { timestamps: true }
);

// Helpful index for search by source/destination/date
flightSchema.index({ source: 1, destination: 1, date: 1 });

module.exports = mongoose.model('Flight', flightSchema);
