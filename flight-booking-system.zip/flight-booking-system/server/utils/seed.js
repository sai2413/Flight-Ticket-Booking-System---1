// Populates the database with a demo admin user and sample flights.
// Run with: npm run seed
const dotenv = require('dotenv');
dotenv.config();

const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const Flight = require('../models/Flight');

const airlines = ['SkyJet Airways', 'BlueWing Air', 'Falcon Airlines', 'Horizon Air'];
const cities = ['Delhi', 'Mumbai', 'Bengaluru', 'Hyderabad', 'Chennai', 'Kolkata'];

const randomFrom = (arr) => arr[Math.floor(Math.random() * arr.length)];

const buildFlights = () => {
  const flights = [];
  for (let i = 0; i < 18; i++) {
    let source = randomFrom(cities);
    let destination = randomFrom(cities);
    while (destination === source) destination = randomFrom(cities);

    const daysAhead = Math.floor(Math.random() * 14) + 1;
    const date = new Date();
    date.setDate(date.getDate() + daysAhead);

    const depHour = Math.floor(Math.random() * 22).toString().padStart(2, '0');
    const arrHour = Math.floor(Math.random() * 22).toString().padStart(2, '0');
    const seats = 40 + Math.floor(Math.random() * 60);

    flights.push({
      flightNumber: `FL${1000 + i}`,
      airline: randomFrom(airlines),
      source,
      destination,
      departureTime: `${depHour}:00`,
      arrivalTime: `${arrHour}:30`,
      date,
      price: 2500 + Math.floor(Math.random() * 7500),
      availableSeats: seats,
      totalSeats: seats,
    });
  }
  return flights;
};

const seed = async () => {
  await connectDB();

  const adminExists = await User.findOne({ email: 'admin@flightbooking.com' });
  if (!adminExists) {
    await User.create({
      name: 'Admin User',
      email: 'admin@flightbooking.com',
      password: 'admin123',
      role: 'admin',
    });
    console.log('Created demo admin -> admin@flightbooking.com / admin123');
  }

  await Flight.deleteMany({});
  await Flight.insertMany(buildFlights());
  console.log('Seeded 18 sample flights');

  await mongoose.connection.close();
  process.exit(0);
};

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
