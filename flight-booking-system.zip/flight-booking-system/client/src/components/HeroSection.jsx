import React from 'react';
import FlightSearchCard from './FlightSearchCard';

const boardRows = [
  { code: 'FL1024', route: 'DEL \u2192 BOM', time: '08:40', status: 'ON TIME' },
  { code: 'FL2091', route: 'BLR \u2192 HYD', time: '11:15', status: 'BOARDING' },
  { code: 'FL3312', route: 'MAA \u2192 CCU', time: '14:05', status: 'ON TIME' },
];

const HeroSection = ({ onSearch }) => {
  return (
    <section className="relative bg-ink-700 overflow-hidden">
      {/* Subtle radar grid backdrop */}
      <div className="absolute inset-0 bg-radar-grid bg-[length:32px_32px] opacity-40" />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-14 pb-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <span className="inline-block px-3 py-1 rounded-full bg-white/10 text-teal-400 text-xs font-semibold tracking-wide mb-5">
              REAL-TIME SEAT AVAILABILITY
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold text-white leading-tight mb-4">
              Every seat, every route, <span className="text-teal-400">tracked live.</span>
            </h1>
            <p className="text-ink-100 text-base sm:text-lg mb-8 max-w-lg">
              SkyRoute pulls flights straight off the board, so the price and seat count
              you see is the one you get at checkout.
            </p>

            {/* Signature element: mini departure board */}
            <div className="hidden sm:block bg-ink-900/60 border border-white/10 rounded-xl overflow-hidden">
              <div className="flex justify-between px-4 py-2 text-[11px] tracking-widest text-teal-400 font-mono border-b border-white/10">
                <span>FLIGHT</span>
                <span>ROUTE</span>
                <span>DEP</span>
                <span>STATUS</span>
              </div>
              {boardRows.map((row) => (
                <div
                  key={row.code}
                  className="flex justify-between items-center px-4 py-2.5 text-sm font-mono text-ink-100 border-b border-white/5 last:border-none"
                >
                  <span className="w-16">{row.code}</span>
                  <span className="w-28">{row.route}</span>
                  <span className="w-14">{row.time}</span>
                  <span className={row.status === 'BOARDING' ? 'text-amber-400' : 'text-teal-400'}>
                    {row.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <FlightSearchCard onSearch={onSearch} />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
