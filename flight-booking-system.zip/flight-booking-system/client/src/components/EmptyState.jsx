import React from 'react';

// Shown whenever a list has no results - explains why and suggests a next action
const EmptyState = ({ icon: Icon, title, message, action }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center py-16 px-4 bg-white rounded-2xl border border-dashed border-ink-100">
      {Icon && (
        <div className="w-14 h-14 rounded-full bg-teal-50 flex items-center justify-center mb-4">
          <Icon className="w-6 h-6 text-teal-600" />
        </div>
      )}
      <h3 className="text-lg font-semibold text-ink-700 mb-1">{title}</h3>
      <p className="text-sm text-ink-400 max-w-sm mb-4">{message}</p>
      {action}
    </div>
  );
};

export default EmptyState;
