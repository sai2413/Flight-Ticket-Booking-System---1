import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  HiOutlineUser,
  HiOutlineTicket,
  HiOutlineSearch,
  HiOutlinePaperAirplane,
  HiOutlineClipboardList,
  HiOutlineChartBar,
} from 'react-icons/hi';

const userLinks = [
  { to: '/profile', label: 'My Profile', icon: HiOutlineUser },
  { to: '/my-bookings', label: 'My Bookings', icon: HiOutlineTicket },
  { to: '/search', label: 'Search Flights', icon: HiOutlineSearch },
];

const adminLinks = [
  { to: '/admin', label: 'Overview', icon: HiOutlineChartBar, end: true },
  { to: '/admin/flights', label: 'Manage Flights', icon: HiOutlinePaperAirplane },
  { to: '/admin/bookings', label: 'Manage Bookings', icon: HiOutlineClipboardList },
];

const Sidebar = ({ variant = 'user' }) => {
  const links = variant === 'admin' ? adminLinks : userLinks;

  return (
    <aside className="w-full sm:w-56 shrink-0">
      <nav className="flex sm:flex-col gap-1 overflow-x-auto sm:overflow-visible bg-white sm:bg-transparent rounded-xl sm:rounded-none p-2 sm:p-0 border sm:border-none border-ink-100">
        {links.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) =>
              `flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap transition ${
                isActive ? 'bg-ink-700 text-white' : 'text-ink-600 hover:bg-ink-50'
              }`
            }
          >
            <Icon className="w-4 h-4 shrink-0" />
            {label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;
