import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { HiOutlinePaperAirplane, HiOutlineMenu, HiOutlineX } from 'react-icons/hi';
import useAuth from '../hooks/useAuth';

const Navbar = () => {
  const { user, logout, isAdmin } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    setOpen(false);
    navigate('/login');
  };

  const linkClass = ({ isActive }) =>
    `text-sm font-medium transition hover:text-teal-500 ${isActive ? 'text-teal-500' : 'text-ink-100'}`;

  return (
    <header className="sticky top-0 z-40 bg-ink-700 border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 text-white font-display font-semibold text-lg">
          <span className="w-8 h-8 rounded-lg bg-teal-500 flex items-center justify-center rotate-45">
            <HiOutlinePaperAirplane className="w-4 h-4 text-ink-900 -rotate-45" />
          </span>
          SkyRoute
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-7">
          <NavLink to="/" className={linkClass} end>Home</NavLink>
          <NavLink to="/search" className={linkClass}>Search Flights</NavLink>
          {user && <NavLink to="/my-bookings" className={linkClass}>My Bookings</NavLink>}
          {isAdmin && <NavLink to="/admin" className={linkClass}>Admin</NavLink>}
        </nav>

        <div className="hidden md:flex items-center gap-3">
          {user ? (
            <>
              <NavLink to="/profile" className="text-sm text-ink-100 hover:text-teal-500">
                Hi, {user.name?.split(' ')[0]}
              </NavLink>
              <button
                onClick={handleLogout}
                className="px-4 py-2 rounded-lg text-sm font-semibold bg-white/10 text-white hover:bg-white/20 transition"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="text-sm font-medium text-ink-100 hover:text-teal-500">Login</Link>
              <Link
                to="/register"
                className="px-4 py-2 rounded-lg text-sm font-semibold bg-amber-500 text-ink-900 hover:bg-amber-400 transition"
              >
                Sign up
              </Link>
            </>
          )}
        </div>

        {/* Mobile toggle */}
        <button className="md:hidden text-white" onClick={() => setOpen(!open)} aria-label="Toggle menu">
          {open ? <HiOutlineX className="w-6 h-6" /> : <HiOutlineMenu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile nav */}
      {open && (
        <div className="md:hidden bg-ink-700 border-t border-white/5 px-4 py-4 flex flex-col gap-4">
          <NavLink to="/" className={linkClass} end onClick={() => setOpen(false)}>Home</NavLink>
          <NavLink to="/search" className={linkClass} onClick={() => setOpen(false)}>Search Flights</NavLink>
          {user && (
            <NavLink to="/my-bookings" className={linkClass} onClick={() => setOpen(false)}>My Bookings</NavLink>
          )}
          {isAdmin && <NavLink to="/admin" className={linkClass} onClick={() => setOpen(false)}>Admin</NavLink>}
          {user ? (
            <>
              <NavLink to="/profile" className={linkClass} onClick={() => setOpen(false)}>My Profile</NavLink>
              <button onClick={handleLogout} className="text-left text-sm font-semibold text-red-300">
                Logout
              </button>
            </>
          ) : (
            <>
              <NavLink to="/login" className={linkClass} onClick={() => setOpen(false)}>Login</NavLink>
              <NavLink to="/register" className={linkClass} onClick={() => setOpen(false)}>Sign up</NavLink>
            </>
          )}
        </div>
      )}
    </header>
  );
};

export default Navbar;
