import React from 'react';

const Pagination = ({ page, pages, onPageChange }) => {
  if (pages <= 1) return null;

  const pageNumbers = Array.from({ length: pages }, (_, i) => i + 1);

  return (
    <div className="flex items-center justify-center gap-2 mt-8">
      <button
        onClick={() => onPageChange(page - 1)}
        disabled={page === 1}
        className="px-3 py-1.5 rounded-lg text-sm font-medium border border-ink-100 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-ink-50 transition"
      >
        Prev
      </button>

      {pageNumbers.map((n) => (
        <button
          key={n}
          onClick={() => onPageChange(n)}
          className={`w-9 h-9 rounded-lg text-sm font-semibold transition ${
            n === page ? 'bg-ink-700 text-white' : 'text-ink-600 hover:bg-ink-50 border border-ink-100'
          }`}
        >
          {n}
        </button>
      ))}

      <button
        onClick={() => onPageChange(page + 1)}
        disabled={page === pages}
        className="px-3 py-1.5 rounded-lg text-sm font-medium border border-ink-100 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-ink-50 transition"
      >
        Next
      </button>
    </div>
  );
};

export default Pagination;
