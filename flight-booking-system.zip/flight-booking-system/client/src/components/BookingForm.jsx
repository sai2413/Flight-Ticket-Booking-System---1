import React, { useState, useMemo } from 'react';

const BookingForm = ({ flight, defaultValues = {}, onSubmit, submitLabel = 'Confirm booking' }) => {
  const [form, setForm] = useState({
    passengerName: defaultValues.passengerName || '',
    email: defaultValues.email || '',
    phone: defaultValues.phone || '',
    seats: defaultValues.seats || 1,
  });
  const [errors, setErrors] = useState({});

  const totalPrice = useMemo(() => (flight ? flight.price * (Number(form.seats) || 0) : 0), [flight, form.seats]);

  const validate = () => {
    const errs = {};
    if (!form.passengerName.trim()) errs.passengerName = 'Passenger name is required';
    if (!form.email.trim()) {
      errs.email = 'Email is required';
    } else if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      errs.email = 'Enter a valid email address';
    }
    if (!form.phone.trim()) {
      errs.phone = 'Phone number is required';
    } else if (!/^[0-9+\-\s]{7,15}$/.test(form.phone)) {
      errs.phone = 'Enter a valid phone number';
    }
    const seatsNum = Number(form.seats);
    if (!seatsNum || seatsNum < 1) {
      errs.seats = 'Book at least 1 seat';
    } else if (flight && seatsNum > flight.availableSeats) {
      errs.seats = `Only ${flight.availableSeats} seat(s) available`;
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleChange = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    onSubmit({ ...form, seats: Number(form.seats), totalPrice });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div>
        <label className="block text-sm font-medium text-ink-600 mb-1.5">Passenger full name</label>
        <input
          value={form.passengerName}
          onChange={handleChange('passengerName')}
          className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
          placeholder="As it appears on your ID"
        />
        {errors.passengerName && <p className="text-xs text-red-500 mt-1">{errors.passengerName}</p>}
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-ink-600 mb-1.5">Email address</label>
          <input
            type="email"
            value={form.email}
            onChange={handleChange('email')}
            className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
            placeholder="you@example.com"
          />
          {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email}</p>}
        </div>
        <div>
          <label className="block text-sm font-medium text-ink-600 mb-1.5">Phone number</label>
          <input
            value={form.phone}
            onChange={handleChange('phone')}
            className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
            placeholder="+91 98765 43210"
          />
          {errors.phone && <p className="text-xs text-red-500 mt-1">{errors.phone}</p>}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-ink-600 mb-1.5">Number of seats</label>
        <input
          type="number"
          min={1}
          max={flight?.availableSeats || 9}
          value={form.seats}
          onChange={handleChange('seats')}
          className="w-full sm:w-40 px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
        />
        {errors.seats && <p className="text-xs text-red-500 mt-1">{errors.seats}</p>}
      </div>

      {flight && (
        <div className="flex items-center justify-between bg-ink-50 rounded-xl px-4 py-3">
          <span className="text-sm text-ink-400">Total price</span>
          <span className="text-xl font-bold text-teal-600 tabular">₹{totalPrice.toLocaleString('en-IN')}</span>
        </div>
      )}

      <button
        type="submit"
        className="w-full py-3 rounded-lg bg-teal-500 hover:bg-teal-600 text-white font-semibold text-sm transition"
      >
        {submitLabel}
      </button>
    </form>
  );
};

export default BookingForm;
