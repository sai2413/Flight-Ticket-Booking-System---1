import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-ink-900 text-ink-100 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid grid-cols-1 sm:grid-cols-3 gap-8">
        <div>
          <p className="font-display font-semibold text-white text-lg mb-2">SkyRoute</p>
          <p className="text-sm text-ink-400">Search, compare, and book flights across the country in minutes.</p>
        </div>
        <div>
          <p className="text-sm font-semibold text-white mb-3">Explore</p>
          <ul className="space-y-2 text-sm text-ink-400">
            <li><Link to="/search" className="hover:text-teal-400">Search Flights</Link></li>
            <li><Link to="/my-bookings" className="hover:text-teal-400">My Bookings</Link></li>
            <li><Link to="/register" className="hover:text-teal-400">Create Account</Link></li>
          </ul>
        </div>
        <div>
          <p className="text-sm font-semibold text-white mb-3">Support</p>
          <ul className="space-y-2 text-sm text-ink-400">
            <li>help@skyroute.demo</li>
            <li>+91 98765 43210</li>
            <li>Mon - Sat, 9am - 7pm</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/5 py-4 text-center text-xs text-ink-400">
        &copy; {new Date().getFullYear()} SkyRoute. Demo project for educational purposes.
      </div>
    </footer>
  );
};

export default Footer;
