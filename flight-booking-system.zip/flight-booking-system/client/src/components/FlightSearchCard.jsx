import React, { useState } from 'react';
import { HiOutlineSwitchHorizontal } from 'react-icons/hi';

const FlightSearchCard = ({ onSearch, initialValues = {} }) => {
  const [source, setSource] = useState(initialValues.source || '');
  const [destination, setDestination] = useState(initialValues.destination || '');
  const [date, setDate] = useState(initialValues.date || '');

  const swap = () => {
    setSource(destination);
    setDestination(source);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSearch({ source: source.trim(), destination: destination.trim(), date });
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white rounded-2xl shadow-xl p-6 sm:p-8 border border-ink-100"
    >
      <h2 className="text-lg font-semibold text-ink-700 mb-5">Find your flight</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-semibold text-ink-400 uppercase tracking-wide mb-1.5">
            From
          </label>
          <input
            type="text"
            value={source}
            onChange={(e) => setSource(e.target.value)}
            placeholder="e.g. Delhi"
            className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
          />
        </div>
        <div className="relative">
          <label className="block text-xs font-semibold text-ink-400 uppercase tracking-wide mb-1.5">
            To
          </label>
          <input
            type="text"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            placeholder="e.g. Mumbai"
            className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
          />
          <button
            type="button"
            onClick={swap}
            aria-label="Swap source and destination"
            className="hidden sm:flex absolute -left-9 top-8 w-7 h-7 rounded-full bg-ink-50 border border-ink-100 items-center justify-center hover:bg-teal-50 transition"
          >
            <HiOutlineSwitchHorizontal className="w-3.5 h-3.5 text-ink-400" />
          </button>
        </div>
        <div className="sm:col-span-2">
          <label className="block text-xs font-semibold text-ink-400 uppercase tracking-wide mb-1.5">
            Departure date
          </label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
          />
        </div>
      </div>
      <button
        type="submit"
        className="w-full mt-6 py-3 rounded-lg bg-teal-500 hover:bg-teal-600 text-white font-semibold text-sm transition"
      >
        Search flights
      </button>
    </form>
  );
};

export default FlightSearchCard;
