import React from 'react';

// Simple radar-sweep style loading spinner matching the aviation theme
const LoadingSpinner = ({ label = 'Loading...', full = false }) => {
  return (
    <div className={`flex flex-col items-center justify-center gap-3 ${full ? 'min-h-[60vh]' : 'py-10'}`}>
      <div className="relative w-12 h-12">
        <div className="absolute inset-0 rounded-full border-4 border-ink-100" />
        <div className="absolute inset-0 rounded-full border-4 border-teal-500 border-t-transparent animate-spin" />
      </div>
      <p className="text-sm text-ink-400 font-medium">{label}</p>
    </div>
  );
};

export default LoadingSpinner;
