import React from 'react';
import { Link } from 'react-router-dom';
import { HiOutlinePaperAirplane } from 'react-icons/hi';

const formatDate = (d) =>
  new Date(d).toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short' });

const FlightCard = ({ flight }) => {
  const lowSeats = flight.availableSeats > 0 && flight.availableSeats <= 5;
  const soldOut = flight.availableSeats === 0;

  return (
    <div className="bg-white rounded-2xl border border-ink-100 hover:border-teal-400 hover:shadow-lg transition p-5 flex flex-col sm:flex-row sm:items-center gap-5">
      <div className="flex-1 grid grid-cols-3 items-center gap-2 tabular">
        <div>
          <p className="text-lg font-semibold text-ink-700">{flight.departureTime}</p>
          <p className="text-xs text-ink-400 uppercase">{flight.source}</p>
        </div>
        <div className="flex flex-col items-center text-ink-400">
          <HiOutlinePaperAirplane className="w-4 h-4 rotate-90 text-teal-500" />
          <span className="text-[10px] mt-1 tracking-wide">{flight.flightNumber}</span>
          <div className="w-full border-t border-dashed border-ink-100 mt-1" />
        </div>
        <div className="text-right">
          <p className="text-lg font-semibold text-ink-700">{flight.arrivalTime}</p>
          <p className="text-xs text-ink-400 uppercase">{flight.destination}</p>
        </div>
      </div>

      <div className="sm:w-40 flex sm:flex-col sm:items-end justify-between gap-1 border-t sm:border-t-0 sm:border-l border-ink-100 pt-3 sm:pt-0 sm:pl-5">
        <div>
          <p className="text-sm font-semibold text-ink-700">{flight.airline}</p>
          <p className="text-xs text-ink-400">{formatDate(flight.date)}</p>
        </div>
        <p className="text-xl font-bold text-teal-600 tabular">₹{flight.price.toLocaleString('en-IN')}</p>
      </div>

      <div className="sm:w-36 flex flex-row sm:flex-col items-center sm:items-end gap-2">
        <span
          className={`text-xs font-medium px-2 py-1 rounded-full ${
            soldOut
              ? 'bg-red-50 text-red-500'
              : lowSeats
              ? 'bg-amber-50 text-amber-600'
              : 'bg-teal-50 text-teal-600'
          }`}
        >
          {soldOut ? 'Sold out' : `${flight.availableSeats} seats left`}
        </span>
        <Link
          to={soldOut ? '#' : `/book/${flight._id}`}
          aria-disabled={soldOut}
          className={`px-5 py-2 rounded-lg text-sm font-semibold transition text-center w-full sm:w-auto ${
            soldOut
              ? 'bg-ink-50 text-ink-400 cursor-not-allowed pointer-events-none'
              : 'bg-ink-700 text-white hover:bg-ink-600'
          }`}
        >
          {soldOut ? 'Unavailable' : 'Book now'}
        </Link>
      </div>
    </div>
  );
};

export default FlightCard;
