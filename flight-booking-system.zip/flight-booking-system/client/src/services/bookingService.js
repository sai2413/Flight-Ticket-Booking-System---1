import api from './api';

export const getBookings = (params) => api.get('/bookings', { params }).then((res) => res.data);
export const getBookingById = (id) => api.get(`/bookings/${id}`).then((res) => res.data);
export const createBooking = (data) => api.post('/bookings', data).then((res) => res.data);
export const updateBooking = (id, data) => api.put(`/bookings/${id}`, data).then((res) => res.data);
export const cancelBooking = (id) => api.delete(`/bookings/${id}`).then((res) => res.data);

export const getAdminStats = () => api.get('/admin/stats').then((res) => res.data);
