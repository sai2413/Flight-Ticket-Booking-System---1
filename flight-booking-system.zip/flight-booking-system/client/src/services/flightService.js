import api from './api';

export const getFlights = (params) => api.get('/flights', { params }).then((res) => res.data);
export const getFlightById = (id) => api.get(`/flights/${id}`).then((res) => res.data);
export const createFlight = (data) => api.post('/flights', data).then((res) => res.data);
export const updateFlight = (id, data) => api.put(`/flights/${id}`, data).then((res) => res.data);
export const deleteFlight = (id) => api.delete(`/flights/${id}`).then((res) => res.data);
