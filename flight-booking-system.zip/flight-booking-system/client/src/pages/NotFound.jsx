import React from 'react';
import { Link } from 'react-router-dom';
import { HiOutlinePaperAirplane } from 'react-icons/hi';

const NotFound = () => (
  <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-4">
    <HiOutlinePaperAirplane className="w-12 h-12 text-teal-500 rotate-45 mb-4" />
    <h1 className="text-4xl font-bold text-ink-700 mb-2">404</h1>
    <p className="text-ink-400 mb-6">This route doesn't exist &mdash; looks like this flight was never scheduled.</p>
    <Link to="/" className="px-5 py-2.5 rounded-lg bg-teal-500 hover:bg-teal-600 text-white font-semibold text-sm transition">
      Back to home
    </Link>
  </div>
);

export default NotFound;
