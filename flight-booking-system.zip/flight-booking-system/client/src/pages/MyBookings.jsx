import React, { useEffect, useState, useCallback } from 'react';
import { toast } from 'react-toastify';
import { HiOutlineTicket, HiOutlinePencil, HiOutlineX } from 'react-icons/hi';
import LoadingSpinner from '../components/LoadingSpinner';
import EmptyState from '../components/EmptyState';
import ConfirmDialog from '../components/ConfirmDialog';
import Pagination from '../components/Pagination';
import { getBookings, updateBooking, cancelBooking } from '../services/bookingService';

const formatDate = (d) => new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

const MyBookings = () => {
  const [data, setData] = useState({ bookings: [], page: 1, pages: 1, total: 0 });
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [page, setPage] = useState(1);
  const [editingBooking, setEditingBooking] = useState(null);
  const [editForm, setEditForm] = useState({ passengerName: '', email: '', phone: '' });
  const [cancelTarget, setCancelTarget] = useState(null);

  const fetchBookings = useCallback(() => {
    setLoading(true);
    getBookings({ status: statusFilter || undefined, page, limit: 6 })
      .then(setData)
      .finally(() => setLoading(false));
  }, [statusFilter, page]);

  useEffect(() => {
    fetchBookings();
  }, [fetchBookings]);

  const openEdit = (booking) => {
    setEditingBooking(booking);
    setEditForm({ passengerName: booking.passengerName, email: booking.email, phone: booking.phone });
  };

  const submitEdit = async (e) => {
    e.preventDefault();
    try {
      await updateBooking(editingBooking._id, editForm);
      toast.success('Passenger details updated');
      setEditingBooking(null);
      fetchBookings();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    }
  };

  const confirmCancel = async () => {
    try {
      await cancelBooking(cancelTarget._id);
      toast.success('Booking cancelled');
      setCancelTarget(null);
      fetchBookings();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Cancellation failed');
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="text-xl font-bold text-ink-700">My bookings</h1>
        <select
          value={statusFilter}
          onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
          className="px-3 py-2 rounded-lg border border-ink-100 text-sm outline-none focus:border-teal-500"
        >
          <option value="">All statuses</option>
          <option value="confirmed">Confirmed</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      {loading ? (
        <LoadingSpinner label="Loading your bookings..." />
      ) : data.bookings.length === 0 ? (
        <EmptyState
          icon={HiOutlineTicket}
          title="No bookings yet"
          message="Once you book a flight, it will show up here."
        />
      ) : (
        <>
          <div className="bg-white rounded-2xl border border-ink-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-ink-50 text-ink-400 text-xs uppercase tracking-wide">
                  <tr>
                    <th className="text-left px-4 py-3">Flight</th>
                    <th className="text-left px-4 py-3">Passenger</th>
                    <th className="text-left px-4 py-3">Seats</th>
                    <th className="text-left px-4 py-3">Total</th>
                    <th className="text-left px-4 py-3">Status</th>
                    <th className="text-right px-4 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {data.bookings.map((b) => (
                    <tr key={b._id} className="border-t border-ink-100">
                      <td className="px-4 py-3">
                        {b.flightId ? (
                          <>
                            <p className="font-medium text-ink-700">{b.flightId.source} → {b.flightId.destination}</p>
                            <p className="text-xs text-ink-400 tabular">{b.flightId.flightNumber} · {formatDate(b.flightId.date)}</p>
                          </>
                        ) : (
                          <span className="text-ink-400">Flight removed</span>
                        )}
                      </td>
                      <td className="px-4 py-3">{b.passengerName}</td>
                      <td className="px-4 py-3 tabular">{b.seats}</td>
                      <td className="px-4 py-3 tabular font-semibold">₹{b.totalPrice.toLocaleString('en-IN')}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium capitalize ${
                            b.bookingStatus === 'confirmed' ? 'bg-teal-50 text-teal-600' : 'bg-red-50 text-red-500'
                          }`}
                        >
                          {b.bookingStatus}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => openEdit(b)}
                            disabled={b.bookingStatus === 'cancelled'}
                            className="p-2 rounded-lg text-ink-400 hover:text-teal-600 hover:bg-teal-50 disabled:opacity-30 disabled:cursor-not-allowed transition"
                            aria-label="Edit passenger details"
                          >
                            <HiOutlinePencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setCancelTarget(b)}
                            disabled={b.bookingStatus === 'cancelled'}
                            className="p-2 rounded-lg text-ink-400 hover:text-red-500 hover:bg-red-50 disabled:opacity-30 disabled:cursor-not-allowed transition"
                            aria-label="Cancel booking"
                          >
                            <HiOutlineX className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <Pagination page={data.page} pages={data.pages} onPageChange={setPage} />
        </>
      )}

      {/* Edit passenger details modal */}
      {editingBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
          <div className="absolute inset-0 bg-ink-900/60 backdrop-blur-sm" onClick={() => setEditingBooking(null)} />
          <form onSubmit={submitEdit} className="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 space-y-4">
            <h3 className="text-lg font-semibold text-ink-700">Update passenger details</h3>
            <div>
              <label className="block text-sm font-medium text-ink-600 mb-1.5">Passenger name</label>
              <input
                value={editForm.passengerName}
                onChange={(e) => setEditForm({ ...editForm, passengerName: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-ink-600 mb-1.5">Email</label>
              <input
                type="email"
                value={editForm.email}
                onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-ink-600 mb-1.5">Phone</label>
              <input
                value={editForm.phone}
                onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
              />
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <button type="button" onClick={() => setEditingBooking(null)} className="px-4 py-2 rounded-lg text-sm font-medium text-ink-600 hover:bg-ink-50">
                Cancel
              </button>
              <button type="submit" className="px-4 py-2 rounded-lg text-sm font-semibold text-white bg-teal-500 hover:bg-teal-600">
                Save changes
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog
        open={!!cancelTarget}
        title="Cancel this booking?"
        message="Your seats will be released back to the flight and this action cannot be undone."
        confirmLabel="Cancel booking"
        onConfirm={confirmCancel}
        onCancel={() => setCancelTarget(null)}
      />
    </div>
  );
};

export default MyBookings;
