import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import HeroSection from '../components/HeroSection';
import FlightCard from '../components/FlightCard';
import LoadingSpinner from '../components/LoadingSpinner';
import EmptyState from '../components/EmptyState';
import { HiOutlinePaperAirplane } from 'react-icons/hi';
import { getFlights } from '../services/flightService';

const Home = () => {
  const navigate = useNavigate();
  const [flights, setFlights] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getFlights({ limit: 6, sort: 'date' })
      .then((data) => setFlights(data.flights))
      .finally(() => setLoading(false));
  }, []);

  const handleSearch = (params) => {
    const query = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v)
    ).toString();
    navigate(`/search?${query}`);
  };

  return (
    <div>
      <HeroSection onSearch={handleSearch} />

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-ink-700">Upcoming departures</h2>
          <button onClick={() => navigate('/search')} className="text-sm font-semibold text-teal-600 hover:underline">
            View all flights
          </button>
        </div>

        {loading ? (
          <LoadingSpinner label="Fetching flights..." />
        ) : flights.length === 0 ? (
          <EmptyState
            icon={HiOutlinePaperAirplane}
            title="No flights scheduled yet"
            message="Check back soon, or ask an admin to add new routes."
          />
        ) : (
          <div className="grid gap-4">
            {flights.map((f) => (
              <FlightCard key={f._id} flight={f} />
            ))}
          </div>
        )}
      </section>

      {/* Value proposition strip */}
      <section className="bg-white border-t border-ink-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid sm:grid-cols-3 gap-8">
          {[
            { title: 'Live seat counts', desc: 'Seat availability updates instantly the moment someone books.' },
            { title: 'Transparent pricing', desc: 'Ticket price × seats, shown before you ever confirm.' },
            { title: 'Manage anytime', desc: 'Update passenger details or cancel from your dashboard.' },
          ].map((item) => (
            <div key={item.title}>
              <h3 className="font-semibold text-ink-700 mb-1.5">{item.title}</h3>
              <p className="text-sm text-ink-400">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
