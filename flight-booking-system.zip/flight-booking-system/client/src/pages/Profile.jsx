import React, { useState } from 'react';
import { toast } from 'react-toastify';
import useAuth from '../hooks/useAuth';
import * as authService from '../services/authService';

const Profile = () => {
  const { user, updateUserInfo } = useAuth();
  const [form, setForm] = useState({ name: user?.name || '', phone: user?.phone || '', password: '' });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { name: form.name, phone: form.phone };
      if (form.password) payload.password = form.password;
      const updated = await authService.updateProfile(payload);
      updateUserInfo(updated);
      toast.success('Profile updated');
      setForm({ ...form, password: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-lg">
      <h1 className="text-xl font-bold text-ink-700 mb-6">My profile</h1>

      <div className="bg-white rounded-2xl border border-ink-100 p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-14 h-14 rounded-full bg-teal-500 text-white flex items-center justify-center text-xl font-bold">
            {user?.name?.[0]?.toUpperCase()}
          </div>
          <div>
            <p className="font-semibold text-ink-700">{user?.name}</p>
            <p className="text-sm text-ink-400">{user?.email}</p>
            <span className="inline-block mt-1 text-xs px-2 py-0.5 rounded-full bg-ink-50 text-ink-600 capitalize">{user?.role}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-ink-600 mb-1.5">Full name</label>
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-ink-600 mb-1.5">Phone</label>
            <input
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-ink-600 mb-1.5">New password</label>
            <input
              type="password"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              placeholder="Leave blank to keep current password"
              className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
            />
          </div>
          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2.5 rounded-lg bg-teal-500 hover:bg-teal-600 disabled:opacity-60 text-white font-semibold text-sm transition"
          >
            {saving ? 'Saving...' : 'Save changes'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Profile;
