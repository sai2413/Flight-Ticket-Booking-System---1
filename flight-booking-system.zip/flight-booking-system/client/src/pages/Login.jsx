import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { toast } from 'react-toastify';
import useAuth from '../hooks/useAuth';
import { HiOutlinePaperAirplane } from 'react-icons/hi';

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const errs = {};
    if (!form.email.trim()) errs.email = 'Email is required';
    else if (!/^\S+@\S+\.\S+$/.test(form.email)) errs.email = 'Enter a valid email address';
    if (!form.password) errs.password = 'Password is required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      await login(form);
      toast.success('Welcome back!');
      navigate(location.state?.from?.pathname || '/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12 bg-ink-50">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-lg border border-ink-100 p-8">
        <div className="flex justify-center mb-5">
          <span className="w-11 h-11 rounded-xl bg-teal-500 flex items-center justify-center rotate-45">
            <HiOutlinePaperAirplane className="w-5 h-5 text-white -rotate-45" />
          </span>
        </div>
        <h1 className="text-2xl font-bold text-ink-700 text-center mb-1">Welcome back</h1>
        <p className="text-sm text-ink-400 text-center mb-6">Log in to manage your bookings</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-ink-600 mb-1.5">Email address</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
              placeholder="you@example.com"
            />
            {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-ink-600 mb-1.5">Password</label>
            <input
              type="password"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm"
              placeholder="••••••••"
            />
            {errors.password && <p className="text-xs text-red-500 mt-1">{errors.password}</p>}
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-lg bg-teal-500 hover:bg-teal-600 disabled:opacity-60 text-white font-semibold text-sm transition"
          >
            {loading ? 'Logging in...' : 'Log in'}
          </button>
        </form>

        <p className="text-center text-sm text-ink-400 mt-6">
          Don't have an account?{' '}
          <Link to="/register" className="text-teal-600 font-semibold hover:underline">
            Sign up
          </Link>
        </p>
        <p className="text-center text-xs text-ink-400 mt-3">
          Demo admin: admin@flightbooking.com / admin123
        </p>
      </div>
    </div>
  );
};

export default Login;
