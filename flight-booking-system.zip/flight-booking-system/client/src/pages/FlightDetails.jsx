import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import { HiOutlinePaperAirplane, HiOutlineArrowLeft } from 'react-icons/hi';
import LoadingSpinner from '../components/LoadingSpinner';
import BookingForm from '../components/BookingForm';
import { getFlightById } from '../services/flightService';
import { createBooking } from '../services/bookingService';
import useAuth from '../hooks/useAuth';

const formatDate = (d) =>
  new Date(d).toLocaleDateString('en-IN', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });

const FlightDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [flight, setFlight] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    getFlightById(id)
      .then(setFlight)
      .catch(() => toast.error('Could not load flight details'))
      .finally(() => setLoading(false));
  }, [id]);

  const handleBook = async (formData) => {
    setSubmitting(true);
    try {
      const booking = await createBooking({
        flightId: id,
        passengerName: formData.passengerName,
        email: formData.email,
        phone: formData.phone,
        seats: formData.seats,
      });
      toast.success('Booking confirmed!');
      navigate(`/booking-confirmation/${booking._id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Booking failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <LoadingSpinner full label="Loading flight details..." />;
  if (!flight) {
    return (
      <div className="text-center py-20">
        <p className="text-ink-400">Flight not found.</p>
        <Link to="/search" className="text-teal-600 font-semibold hover:underline">Back to search</Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-1.5 text-sm text-ink-400 hover:text-teal-600 mb-6"
      >
        <HiOutlineArrowLeft className="w-4 h-4" /> Back
      </button>

      <div className="grid lg:grid-cols-[1fr_380px] gap-8">
        {/* Flight summary */}
        <div className="bg-white rounded-2xl border border-ink-100 p-6 h-fit">
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-sm font-semibold text-teal-600">{flight.airline}</p>
              <p className="text-xs text-ink-400 tabular">{flight.flightNumber} · {formatDate(flight.date)}</p>
            </div>
            <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-teal-50 text-teal-600">
              {flight.availableSeats} seats left
            </span>
          </div>

          <div className="grid grid-cols-3 items-center gap-2 tabular mb-6">
            <div>
              <p className="text-2xl font-bold text-ink-700">{flight.departureTime}</p>
              <p className="text-sm text-ink-400 uppercase">{flight.source}</p>
            </div>
            <div className="flex flex-col items-center text-ink-400">
              <HiOutlinePaperAirplane className="w-5 h-5 rotate-90 text-teal-500 mb-1" />
              <div className="w-full border-t border-dashed border-ink-100" />
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-ink-700">{flight.arrivalTime}</p>
              <p className="text-sm text-ink-400 uppercase">{flight.destination}</p>
            </div>
          </div>

          <div className="grid sm:grid-cols-3 gap-4 border-t border-ink-100 pt-5 text-sm">
            <div>
              <p className="text-ink-400">Ticket price</p>
              <p className="font-semibold text-ink-700 tabular">₹{flight.price.toLocaleString('en-IN')}</p>
            </div>
            <div>
              <p className="text-ink-400">Total seats</p>
              <p className="font-semibold text-ink-700 tabular">{flight.totalSeats}</p>
            </div>
            <div>
              <p className="text-ink-400">Flight date</p>
              <p className="font-semibold text-ink-700">{formatDate(flight.date)}</p>
            </div>
          </div>
        </div>

        {/* Booking form */}
        <div className="bg-white rounded-2xl border border-ink-100 p-6 h-fit">
          <h2 className="text-lg font-semibold text-ink-700 mb-4">Passenger details</h2>
          {!user ? (
            <div className="text-center py-6">
              <p className="text-sm text-ink-400 mb-4">Please log in to book this flight.</p>
              <Link
                to="/login"
                state={{ from: { pathname: `/book/${id}` } }}
                className="inline-block px-5 py-2.5 rounded-lg bg-teal-500 hover:bg-teal-600 text-white font-semibold text-sm transition"
              >
                Log in to continue
              </Link>
            </div>
          ) : flight.availableSeats === 0 ? (
            <p className="text-sm text-red-500">This flight is sold out.</p>
          ) : (
            <BookingForm
              flight={flight}
              defaultValues={{ passengerName: user.name, email: user.email }}
              onSubmit={handleBook}
              submitLabel={submitting ? 'Booking...' : 'Confirm booking'}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default FlightDetails;
