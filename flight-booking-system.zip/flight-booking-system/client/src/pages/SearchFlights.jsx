import React, { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import FlightSearchCard from '../components/FlightSearchCard';
import FlightCard from '../components/FlightCard';
import LoadingSpinner from '../components/LoadingSpinner';
import EmptyState from '../components/EmptyState';
import Pagination from '../components/Pagination';
import { HiOutlineSearch } from 'react-icons/hi';
import { getFlights } from '../services/flightService';

const SearchFlights = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [result, setResult] = useState({ flights: [], page: 1, pages: 1, total: 0 });
  const [loading, setLoading] = useState(true);
  const [sort, setSort] = useState('date');

  const source = searchParams.get('source') || '';
  const destination = searchParams.get('destination') || '';
  const date = searchParams.get('date') || '';
  const page = parseInt(searchParams.get('page') || '1', 10);

  const fetchFlights = useCallback(() => {
    setLoading(true);
    getFlights({ source, destination, date, page, limit: 6, sort })
      .then(setResult)
      .finally(() => setLoading(false));
  }, [source, destination, date, page, sort]);

  useEffect(() => {
    fetchFlights();
  }, [fetchFlights]);

  const handleSearch = (params) => {
    const query = { ...params, page: '1' };
    setSearchParams(Object.fromEntries(Object.entries(query).filter(([, v]) => v)));
  };

  const handlePageChange = (newPage) => {
    const next = new URLSearchParams(searchParams);
    next.set('page', newPage);
    setSearchParams(next);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="grid lg:grid-cols-[380px_1fr] gap-8">
        <div className="lg:sticky lg:top-24 h-fit">
          <FlightSearchCard onSearch={handleSearch} initialValues={{ source, destination, date }} />
        </div>

        <div>
          <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
            <h1 className="text-xl font-bold text-ink-700">
              {loading ? 'Searching...' : `${result.total} flight${result.total === 1 ? '' : 's'} found`}
            </h1>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="px-3 py-2 rounded-lg border border-ink-100 text-sm text-ink-600 outline-none focus:border-teal-500"
            >
              <option value="date">Sort: Date</option>
              <option value="departure">Sort: Departure time</option>
              <option value="priceAsc">Sort: Price (low to high)</option>
              <option value="priceDesc">Sort: Price (high to low)</option>
            </select>
          </div>

          {loading ? (
            <LoadingSpinner label="Fetching matching flights..." />
          ) : result.flights.length === 0 ? (
            <EmptyState
              icon={HiOutlineSearch}
              title="No flights match your search"
              message="Try a different source, destination, or date."
            />
          ) : (
            <>
              <div className="grid gap-4">
                {result.flights.map((f) => (
                  <FlightCard key={f._id} flight={f} />
                ))}
              </div>
              <Pagination page={result.page} pages={result.pages} onPageChange={handlePageChange} />
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default SearchFlights;
