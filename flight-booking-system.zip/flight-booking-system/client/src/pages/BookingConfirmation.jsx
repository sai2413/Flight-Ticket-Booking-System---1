import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { HiCheckCircle } from 'react-icons/hi';
import LoadingSpinner from '../components/LoadingSpinner';
import { getBookingById } from '../services/bookingService';

const BookingConfirmation = () => {
  const { id } = useParams();
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getBookingById(id).then(setBooking).finally(() => setLoading(false));
  }, [id]);

  if (loading) return <LoadingSpinner full label="Loading your confirmation..." />;
  if (!booking) return <p className="text-center py-20 text-ink-400">Booking not found.</p>;

  const { flightId: flight } = booking;

  return (
    <div className="max-w-lg mx-auto px-4 py-14">
      <div className="bg-white rounded-2xl border border-ink-100 p-8 text-center">
        <div className="w-16 h-16 rounded-full bg-teal-50 flex items-center justify-center mx-auto mb-4">
          <HiCheckCircle className="w-9 h-9 text-teal-500" />
        </div>
        <h1 className="text-xl font-bold text-ink-700 mb-1">Booking confirmed!</h1>
        <p className="text-sm text-ink-400 mb-6">A confirmation has been recorded under your account.</p>

        <div className="text-left bg-ink-50 rounded-xl p-5 space-y-2 text-sm mb-6">
          <div className="flex justify-between"><span className="text-ink-400">Booking ID</span><span className="font-mono">{booking._id}</span></div>
          <div className="flex justify-between"><span className="text-ink-400">Passenger</span><span className="font-medium">{booking.passengerName}</span></div>
          {flight && (
            <>
              <div className="flex justify-between"><span className="text-ink-400">Flight</span><span className="font-medium">{flight.flightNumber} · {flight.airline}</span></div>
              <div className="flex justify-between"><span className="text-ink-400">Route</span><span className="font-medium">{flight.source} → {flight.destination}</span></div>
            </>
          )}
          <div className="flex justify-between"><span className="text-ink-400">Seats</span><span className="font-medium">{booking.seats}</span></div>
          <div className="flex justify-between"><span className="text-ink-400">Total paid</span><span className="font-semibold text-teal-600">₹{booking.totalPrice.toLocaleString('en-IN')}</span></div>
          <div className="flex justify-between"><span className="text-ink-400">Status</span><span className="font-medium capitalize">{booking.bookingStatus}</span></div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <Link to="/my-bookings" className="flex-1 py-2.5 rounded-lg bg-ink-700 text-white text-sm font-semibold hover:bg-ink-600 transition">
            View my bookings
          </Link>
          <Link to="/search" className="flex-1 py-2.5 rounded-lg border border-ink-100 text-ink-600 text-sm font-semibold hover:bg-ink-50 transition">
            Book another flight
          </Link>
        </div>
      </div>
    </div>
  );
};

export default BookingConfirmation;
