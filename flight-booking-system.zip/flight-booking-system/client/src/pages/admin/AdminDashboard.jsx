import React, { useEffect, useState } from 'react';
import { HiOutlineUsers, HiOutlinePaperAirplane, HiOutlineCash, HiOutlineTicket } from 'react-icons/hi';
import LoadingSpinner from '../../components/LoadingSpinner';
import { getAdminStats } from '../../services/bookingService';

const StatCard = ({ icon: Icon, label, value, accent }) => (
  <div className="bg-white rounded-2xl border border-ink-100 p-5 flex items-center gap-4">
    <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${accent}`}>
      <Icon className="w-5 h-5" />
    </div>
    <div>
      <p className="text-xs text-ink-400 uppercase tracking-wide">{label}</p>
      <p className="text-xl font-bold text-ink-700 tabular">{value}</p>
    </div>
  </div>
);

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAdminStats().then(setStats).finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSpinner label="Loading dashboard..." />;

  return (
    <div>
      <h1 className="text-xl font-bold text-ink-700 mb-6">Admin overview</h1>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={HiOutlineUsers} label="Total Users" value={stats?.totalUsers ?? 0} accent="bg-teal-50 text-teal-600" />
        <StatCard icon={HiOutlinePaperAirplane} label="Total Flights" value={stats?.totalFlights ?? 0} accent="bg-ink-50 text-ink-700" />
        <StatCard icon={HiOutlineTicket} label="Confirmed Bookings" value={stats?.totalBookings ?? 0} accent="bg-amber-400/10 text-amber-500" />
        <StatCard
          icon={HiOutlineCash}
          label="Total Revenue"
          value={`₹${(stats?.totalRevenue ?? 0).toLocaleString('en-IN')}`}
          accent="bg-teal-50 text-teal-600"
        />
      </div>

      <div className="mt-8 bg-white rounded-2xl border border-ink-100 p-6">
        <h2 className="font-semibold text-ink-700 mb-2">Quick actions</h2>
        <p className="text-sm text-ink-400 mb-4">Jump straight into managing flights or reviewing bookings.</p>
        <div className="flex flex-wrap gap-3">
          <a href="/admin/flights" className="px-4 py-2 rounded-lg bg-ink-700 text-white text-sm font-semibold hover:bg-ink-600 transition">
            Manage flights
          </a>
          <a href="/admin/bookings" className="px-4 py-2 rounded-lg border border-ink-100 text-ink-600 text-sm font-semibold hover:bg-ink-50 transition">
            Manage bookings
          </a>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
