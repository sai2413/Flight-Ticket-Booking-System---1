import React, { useEffect, useState, useCallback } from 'react';
import { toast } from 'react-toastify';
import { HiOutlineClipboardList, HiOutlineX, HiOutlineSearch } from 'react-icons/hi';
import LoadingSpinner from '../../components/LoadingSpinner';
import EmptyState from '../../components/EmptyState';
import ConfirmDialog from '../../components/ConfirmDialog';
import Pagination from '../../components/Pagination';
import { getBookings, cancelBooking } from '../../services/bookingService';

const ManageBookings = () => {
  const [data, setData] = useState({ bookings: [], page: 1, pages: 1, total: 0 });
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [cancelTarget, setCancelTarget] = useState(null);

  const fetchBookings = useCallback(() => {
    setLoading(true);
    getBookings({ status: status || undefined, search: search || undefined, page, limit: 8 })
      .then(setData)
      .finally(() => setLoading(false));
  }, [status, search, page]);

  useEffect(() => {
    fetchBookings();
  }, [fetchBookings]);

  const confirmCancel = async () => {
    try {
      await cancelBooking(cancelTarget._id);
      toast.success('Booking cancelled');
      setCancelTarget(null);
      fetchBookings();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Cancellation failed');
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="text-xl font-bold text-ink-700">Manage bookings</h1>
        <div className="flex gap-2 flex-wrap">
          <div className="relative">
            <HiOutlineSearch className="w-4 h-4 text-ink-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder="Search passenger or email"
              className="pl-9 pr-3 py-2 rounded-lg border border-ink-100 text-sm outline-none focus:border-teal-500 w-56"
            />
          </div>
          <select
            value={status}
            onChange={(e) => { setStatus(e.target.value); setPage(1); }}
            className="px-3 py-2 rounded-lg border border-ink-100 text-sm outline-none focus:border-teal-500"
          >
            <option value="">All statuses</option>
            <option value="confirmed">Confirmed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      {loading ? (
        <LoadingSpinner label="Loading bookings..." />
      ) : data.bookings.length === 0 ? (
        <EmptyState icon={HiOutlineClipboardList} title="No bookings found" message="Try adjusting your filters." />
      ) : (
        <>
          <div className="bg-white rounded-2xl border border-ink-100 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-ink-50 text-ink-400 text-xs uppercase tracking-wide">
                <tr>
                  <th className="text-left px-4 py-3">Passenger</th>
                  <th className="text-left px-4 py-3">User</th>
                  <th className="text-left px-4 py-3">Flight</th>
                  <th className="text-left px-4 py-3">Seats</th>
                  <th className="text-left px-4 py-3">Total</th>
                  <th className="text-left px-4 py-3">Status</th>
                  <th className="text-right px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.bookings.map((b) => (
                  <tr key={b._id} className="border-t border-ink-100">
                    <td className="px-4 py-3">
                      <p className="font-medium text-ink-700">{b.passengerName}</p>
                      <p className="text-xs text-ink-400">{b.email}</p>
                    </td>
                    <td className="px-4 py-3 text-ink-400">{b.userId?.name || '—'}</td>
                    <td className="px-4 py-3">
                      {b.flightId ? (
                        <>
                          <p className="tabular">{b.flightId.flightNumber}</p>
                          <p className="text-xs text-ink-400">{b.flightId.source} → {b.flightId.destination}</p>
                        </>
                      ) : '—'}
                    </td>
                    <td className="px-4 py-3 tabular">{b.seats}</td>
                    <td className="px-4 py-3 tabular font-semibold">₹{b.totalPrice.toLocaleString('en-IN')}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium capitalize ${
                        b.bookingStatus === 'confirmed' ? 'bg-teal-50 text-teal-600' : 'bg-red-50 text-red-500'
                      }`}>
                        {b.bookingStatus}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end">
                        <button
                          onClick={() => setCancelTarget(b)}
                          disabled={b.bookingStatus === 'cancelled'}
                          className="p-2 rounded-lg text-ink-400 hover:text-red-500 hover:bg-red-50 disabled:opacity-30 disabled:cursor-not-allowed transition"
                          aria-label="Cancel booking"
                        >
                          <HiOutlineX className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={data.page} pages={data.pages} onPageChange={setPage} />
        </>
      )}

      <ConfirmDialog
        open={!!cancelTarget}
        title="Cancel this booking?"
        message="Seats will be released back to the flight for other users to book."
        confirmLabel="Cancel booking"
        onConfirm={confirmCancel}
        onCancel={() => setCancelTarget(null)}
      />
    </div>
  );
};

export default ManageBookings;
