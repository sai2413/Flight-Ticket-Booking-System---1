import React, { useEffect, useState, useCallback } from 'react';
import { toast } from 'react-toastify';
import { HiOutlinePlus, HiOutlinePencil, HiOutlineTrash, HiOutlinePaperAirplane } from 'react-icons/hi';
import LoadingSpinner from '../../components/LoadingSpinner';
import EmptyState from '../../components/EmptyState';
import ConfirmDialog from '../../components/ConfirmDialog';
import Pagination from '../../components/Pagination';
import { getFlights, createFlight, updateFlight, deleteFlight } from '../../services/flightService';

const emptyForm = {
  flightNumber: '', airline: '', source: '', destination: '',
  departureTime: '', arrivalTime: '', date: '', price: '', availableSeats: '',
};

const ManageFlights = () => {
  const [data, setData] = useState({ flights: [], page: 1, pages: 1, total: 0 });
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [saving, setSaving] = useState(false);

  const fetchFlights = useCallback(() => {
    setLoading(true);
    getFlights({ page, limit: 8, sort: 'date' }).then(setData).finally(() => setLoading(false));
  }, [page]);

  useEffect(() => {
    fetchFlights();
  }, [fetchFlights]);

  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm);
    setErrors({});
    setModalOpen(true);
  };

  const openEdit = (flight) => {
    setEditingId(flight._id);
    setForm({
      flightNumber: flight.flightNumber,
      airline: flight.airline,
      source: flight.source,
      destination: flight.destination,
      departureTime: flight.departureTime,
      arrivalTime: flight.arrivalTime,
      date: new Date(flight.date).toISOString().slice(0, 10),
      price: flight.price,
      availableSeats: flight.availableSeats,
    });
    setErrors({});
    setModalOpen(true);
  };

  const validate = () => {
    const errs = {};
    ['flightNumber', 'airline', 'source', 'destination', 'departureTime', 'arrivalTime', 'date'].forEach((f) => {
      if (!form[f]) errs[f] = 'Required';
    });
    if (form.source && form.destination && form.source.trim().toLowerCase() === form.destination.trim().toLowerCase()) {
      errs.destination = 'Must differ from source';
    }
    if (!form.price || Number(form.price) < 0) errs.price = 'Enter a valid price';
    if (form.availableSeats === '' || Number(form.availableSeats) < 0) errs.availableSeats = 'Enter valid seats';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSaving(true);
    const payload = { ...form, price: Number(form.price), availableSeats: Number(form.availableSeats) };
    try {
      if (editingId) {
        await updateFlight(editingId, payload);
        toast.success('Flight updated');
      } else {
        await createFlight(payload);
        toast.success('Flight added');
      }
      setModalOpen(false);
      fetchFlights();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    try {
      await deleteFlight(deleteTarget._id);
      toast.success('Flight deleted');
      setDeleteTarget(null);
      fetchFlights();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Delete failed');
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="text-xl font-bold text-ink-700">Manage flights</h1>
        <button
          onClick={openCreate}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-teal-500 hover:bg-teal-600 text-white text-sm font-semibold transition"
        >
          <HiOutlinePlus className="w-4 h-4" /> Add flight
        </button>
      </div>

      {loading ? (
        <LoadingSpinner label="Loading flights..." />
      ) : data.flights.length === 0 ? (
        <EmptyState icon={HiOutlinePaperAirplane} title="No flights yet" message="Add your first flight to get started." />
      ) : (
        <>
          <div className="bg-white rounded-2xl border border-ink-100 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-ink-50 text-ink-400 text-xs uppercase tracking-wide">
                <tr>
                  <th className="text-left px-4 py-3">Flight</th>
                  <th className="text-left px-4 py-3">Route</th>
                  <th className="text-left px-4 py-3">Date</th>
                  <th className="text-left px-4 py-3">Price</th>
                  <th className="text-left px-4 py-3">Seats</th>
                  <th className="text-right px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.flights.map((f) => (
                  <tr key={f._id} className="border-t border-ink-100">
                    <td className="px-4 py-3">
                      <p className="font-medium text-ink-700 tabular">{f.flightNumber}</p>
                      <p className="text-xs text-ink-400">{f.airline}</p>
                    </td>
                    <td className="px-4 py-3">{f.source} → {f.destination}</td>
                    <td className="px-4 py-3">{new Date(f.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</td>
                    <td className="px-4 py-3 tabular">₹{f.price.toLocaleString('en-IN')}</td>
                    <td className="px-4 py-3 tabular">{f.availableSeats}/{f.totalSeats}</td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button onClick={() => openEdit(f)} className="p-2 rounded-lg text-ink-400 hover:text-teal-600 hover:bg-teal-50 transition" aria-label="Edit flight">
                          <HiOutlinePencil className="w-4 h-4" />
                        </button>
                        <button onClick={() => setDeleteTarget(f)} className="p-2 rounded-lg text-ink-400 hover:text-red-500 hover:bg-red-50 transition" aria-label="Delete flight">
                          <HiOutlineTrash className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={data.page} pages={data.pages} onPageChange={setPage} />
        </>
      )}

      {/* Add/Edit modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4 py-8 overflow-y-auto">
          <div className="absolute inset-0 bg-ink-900/60 backdrop-blur-sm" onClick={() => setModalOpen(false)} />
          <form onSubmit={handleSubmit} className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl p-6 space-y-4 my-auto">
            <h3 className="text-lg font-semibold text-ink-700">{editingId ? 'Edit flight' : 'Add new flight'}</h3>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-ink-600 mb-1.5">Flight number</label>
                <input value={form.flightNumber} onChange={(e) => setForm({ ...form, flightNumber: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm" placeholder="FL1234" />
                {errors.flightNumber && <p className="text-xs text-red-500 mt-1">{errors.flightNumber}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-ink-600 mb-1.5">Airline</label>
                <input value={form.airline} onChange={(e) => setForm({ ...form, airline: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm" placeholder="SkyJet Airways" />
                {errors.airline && <p className="text-xs text-red-500 mt-1">{errors.airline}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-ink-600 mb-1.5">Source</label>
                <input value={form.source} onChange={(e) => setForm({ ...form, source: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm" placeholder="Delhi" />
                {errors.source && <p className="text-xs text-red-500 mt-1">{errors.source}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-ink-600 mb-1.5">Destination</label>
                <input value={form.destination} onChange={(e) => setForm({ ...form, destination: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm" placeholder="Mumbai" />
                {errors.destination && <p className="text-xs text-red-500 mt-1">{errors.destination}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-ink-600 mb-1.5">Departure time</label>
                <input type="time" value={form.departureTime} onChange={(e) => setForm({ ...form, departureTime: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm" />
                {errors.departureTime && <p className="text-xs text-red-500 mt-1">{errors.departureTime}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-ink-600 mb-1.5">Arrival time</label>
                <input type="time" value={form.arrivalTime} onChange={(e) => setForm({ ...form, arrivalTime: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm" />
                {errors.arrivalTime && <p className="text-xs text-red-500 mt-1">{errors.arrivalTime}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-ink-600 mb-1.5">Date</label>
                <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm" />
                {errors.date && <p className="text-xs text-red-500 mt-1">{errors.date}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-ink-600 mb-1.5">Ticket price (₹)</label>
                <input type="number" min="0" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm" placeholder="4999" />
                {errors.price && <p className="text-xs text-red-500 mt-1">{errors.price}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-ink-600 mb-1.5">Available seats</label>
                <input type="number" min="0" value={form.availableSeats} onChange={(e) => setForm({ ...form, availableSeats: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-ink-100 focus:border-teal-500 outline-none text-sm" placeholder="60" />
                {errors.availableSeats && <p className="text-xs text-red-500 mt-1">{errors.availableSeats}</p>}
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button type="button" onClick={() => setModalOpen(false)} className="px-4 py-2 rounded-lg text-sm font-medium text-ink-600 hover:bg-ink-50">
                Cancel
              </button>
              <button type="submit" disabled={saving} className="px-4 py-2 rounded-lg text-sm font-semibold text-white bg-teal-500 hover:bg-teal-600 disabled:opacity-60">
                {saving ? 'Saving...' : editingId ? 'Save changes' : 'Add flight'}
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete this flight?"
        message="This will permanently remove the flight. Existing bookings referencing it will stay in history."
        confirmLabel="Delete flight"
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};

export default ManageFlights;
